﻿using Ludiq;

namespace Bolt
{
	public interface IUnitRelation : IConnection<IUnitPort, IUnitPort> { }
}